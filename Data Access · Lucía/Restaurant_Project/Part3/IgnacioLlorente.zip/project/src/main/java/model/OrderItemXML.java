package model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class OrderItemXML {
    private MenuItemXML menuItem;
    private int quantity;

    public MenuItemXML getMenuItem() {
        if (menuItem == null) {
            menuItem = new MenuItemXML();
        }
        return menuItem;
    }
}
