package dao.impl;

import common.Constants;
import common.config.Configuration;
import dao.MenuItemDAO;
import io.vavr.control.Either;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import lombok.extern.log4j.Log4j2;
import model.*;


import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
@Log4j2
public class MenuItemDAOImpl implements MenuItemDAO{
    @Override
    public Either<String, List<MenuItem>> getAll() {
        try {
            Path xmlFilePath = Paths.get(Configuration.getInstance().getOrderItemsDataFile());
            File file = xmlFilePath.toFile();

            JAXBContext jaxbContext = JAXBContext.newInstance(OrdersXML.class); // Usar OrdersXML en lugar de MenuItemsXML
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            OrdersXML ordersXML = (OrdersXML) jaxbUnmarshaller.unmarshal(file);

            if (ordersXML != null) {
                List<MenuItem> menuItems = new ArrayList<>();
                for (OrderXML orderXML : ordersXML.getOrderListXML()) {
                    for (OrderItemXML orderItemXML : orderXML.getOrderItems()) {
                        MenuItem menuItem = new MenuItem();
                        menuItem.setId(orderItemXML.getMenuItem().getId());
                        menuItem.setName(orderItemXML.getMenuItem().getName());
                        menuItem.setDescription(orderItemXML.getMenuItem().getDescription());
                        menuItem.setPrice(orderItemXML.getMenuItem().getPrice());
                        menuItems.add(menuItem);
                    }
                }
                return Either.right(menuItems);
            } else {
                return Either.left(Constants.MENUITEMSXMLREADERROR);
            }

        } catch (JAXBException e) {
            log.error(Constants.ERRDB + e.getMessage());
            return Either.left(Constants.MENUITEMSXMLREADERROR);
        }
    }



    public Either<String, MenuItem> get(int id) {
        List<MenuItem> menuItems = getAll().get();
        for (MenuItem menuItem : menuItems) {
            if (menuItem.getId() == id) {
                return Either.right(menuItem);
            }
        }
        return Either.left(Constants.MENUITEMNOTFOUND+ " Requested ID: "+id);
    }

    @Override
    public int save(MenuItem m) {
        try {
            // Obtén la lista actual de MenuItem
            List<MenuItem> menuItems = getAll().get();

            // Asigna un nuevo ID al nuevo MenuItem
            int newId = generateNewId(menuItems);
            m.setId(newId);

            // Agrega el nuevo MenuItem a la lista
            menuItems.add(m);

            // Guarda la lista actualizada en el archivo XML
            saveMenuItemsToXml(menuItems);

            return newId;
        } catch (Exception e) {
            log.error("Error al guardar el MenuItem: " + e.getMessage());
            return -1; // Retorna un valor de error en caso de fallo
        }
    }

    @Override
    public int modify(MenuItem m) {
        try {
            // Obtén la lista actual de MenuItem
            List<MenuItem> menuItems = getAll().get();

            // Busca el MenuItem con el mismo ID y modifica sus atributos
            for (MenuItem menuItem : menuItems) {
                if (menuItem.getId() == m.getId()) {
                    menuItem.setName(m.getName());
                    menuItem.setDescription(m.getDescription());
                    menuItem.setPrice(m.getPrice());
                    break; // Se encontró y se modificó, salir del bucle
                }
            }

            // Guarda la lista actualizada en el archivo XML
            saveMenuItemsToXml(menuItems);

            return m.getId();
        } catch (Exception e) {
            log.error("Error al modificar el MenuItem: " + e.getMessage());
            return -1; // Retorna un valor de error en caso de fallo
        }
    }

    @Override
    public int delete(MenuItem m) {
        try {
            // Obtén la lista actual de MenuItem
            List<MenuItem> menuItems = getAll().get();

            // Busca el MenuItem con el mismo ID y elimínalo
            menuItems.removeIf(menuItem -> menuItem.getId() == m.getId());

            // Guarda la lista actualizada en el archivo XML
            saveMenuItemsToXml(menuItems);

            return m.getId();
        } catch (Exception e) {
            log.error("Error al eliminar el MenuItem: " + e.getMessage());
            return -1; // Retorna un valor de error en caso de fallo
        }
    }

    private int generateNewId(List<MenuItem> menuItems) {
        // Encuentra el máximo ID actual en la lista de MenuItem
        int maxId = 0;
        for (MenuItem menuItem : menuItems) {
            if (menuItem.getId() > maxId) {
                maxId = menuItem.getId();
            }
        }

        // Incrementa el ID máximo en uno para generar un nuevo ID
        return maxId + 1;
    }

    private void saveMenuItemsToXml(List<MenuItem> menuItems) {
        try {
            // Convierte la lista de MenuItem a MenuItemsXML
            MenuItemsXML menuItemsXML = new MenuItemsXML();
            for (MenuItem menuItem : menuItems) {
                MenuItemXML menuItemXML = new MenuItemXML();
                menuItemXML.setId(menuItem.getId());
                menuItemXML.setName(menuItem.getName());
                menuItemXML.setDescription(menuItem.getDescription());
                menuItemXML.setPrice(menuItem.getPrice());
                menuItemsXML.getMenuItems().add(menuItemXML);
            }

            // Guarda la estructura MenuItemsXML en el archivo XML
            JAXBContext jaxbContext = JAXBContext.newInstance(MenuItemsXML.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            // Establece la propiedad para formatear la salida XML (opcional)
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            // Guarda en el archivo XML
            Path xmlFilePath = Paths.get(Configuration.getInstance().getOrderItemsDataFile());
            File file = xmlFilePath.toFile();
            jaxbMarshaller.marshal(menuItemsXML, file);
        } catch (Exception e) {
            log.error("Error al guardar los elementos de MenuItem en el archivo XML: " + e.getMessage());
        }
    }

}
