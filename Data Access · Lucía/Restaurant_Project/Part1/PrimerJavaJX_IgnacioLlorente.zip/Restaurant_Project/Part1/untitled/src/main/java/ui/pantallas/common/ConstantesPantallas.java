package ui.pantallas.common;

public class ConstantesPantallas {
    public static final String FXML_PANTALLA_NUEVA_FXML = "/fxml/pantallaNueva.fxml";
}
