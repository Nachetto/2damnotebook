package common;

public class Constants {
    public static final String BIENVENIDA = "WELLCOME BACK, ";
    public static final String USERRNOTADDED = "Error on making the user";
    public static final String USERADDED = "User added";
    public static final String CUSTOMERUPDATED = "Customer Updated Correctly";
    public static final String CUSTOMERNOINFO = "the selected customer is empty";
    public static final String CUSTOMERDELETED = "Customer deleted";
    public static final String CUSTOMERNOTDELETED = "The customer has not been deleted";
    public static final String ORDERADDED = "The order has been added succesfully";
    public static final String ORDERITEMADDED = "The order item has been added succesfully";
    public static final String ORDERITEMREMOVED = "The order item has been succesfully removed";
    public static final String ORDERDELETED = "The order has been deleted succesfully";
    public static final String ORDERUPDATED = "The order has been updated succesfully";
}
