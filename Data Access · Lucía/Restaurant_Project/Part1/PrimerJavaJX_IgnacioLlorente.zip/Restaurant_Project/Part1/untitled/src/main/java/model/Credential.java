package model;

public record Credential(String username, String password) {
}
