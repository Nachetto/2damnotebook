package org.example.nachoHibernateConSpring.common;

public class Constants {
    public static final String CONFIG_FILE_PATH = "config/config.properties";


    private Constants() {

    }

    //DATA FILES PATH PROPERTY NAMES
    public static final String PATH_SESSION = "pathSession";
}
