package org.example.nachoHibernateConSpring.domain.error;

public class MedicalRecordException extends RuntimeException {
    public MedicalRecordException(String message) {
        super(message);
    }
}
