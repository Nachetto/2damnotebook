package com.hospitalcrud.dao.repository.hibernate;


import com.hospitalcrud.dao.connection.JPAUtil;
import com.hospitalcrud.dao.model.Credential;
import com.hospitalcrud.dao.repository.CredentialDAO;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@Profile("hibernate")
@Log4j2
public class CredentialRepository implements CredentialDAO {
    private final JPAUtil jpautil;
    private EntityManager em;

    public CredentialRepository(JPAUtil jpautil) {
        this.jpautil = jpautil;
    }


    @Override
    public List<Credential> getAll() {

        List<Credential> list;
        try {
            em = jpautil.getEntityManager();
            list = em.createNamedQuery("Credential.login", Credential.class).getResultList();
        } finally {
            if (em != null) em.close();
        }

        return list;
    }

    @Override
    public int save(Credential c) {
        return 0;
    }

    @Override
    public void update(Credential c) {

    }

    @Override
    public boolean delete(int id) {
        return false;
    }
}
