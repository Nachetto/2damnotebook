package com.hospitalcrud.dao.model;

import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Table(name = "user_login")
@NamedQueries({
        @NamedQuery(name = "Credential.login", query = "FROM Credential where username = :username")
})
public class Credential {
    private String username;
    private String password;
    private int patientId;
}
