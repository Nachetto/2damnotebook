package com.hospitalcrud.service;

import org.springframework.stereotype.Service;

@Service
public class CredentialService {
    // TODO IMPLEMENTAR CREDENCIALES, METODOS DE AUTENTICACION
}
