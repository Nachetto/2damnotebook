package com.hospitalcrud.domain.error;

public class MedicalRecordException extends RuntimeException {
    public MedicalRecordException(String message) {
        super(message);
    }
}
