package com.hospitalcrud.service;

import org.springframework.stereotype.Service;

@Service
public class MedicationService {
    // not implemented for this exercise, created on client
}
