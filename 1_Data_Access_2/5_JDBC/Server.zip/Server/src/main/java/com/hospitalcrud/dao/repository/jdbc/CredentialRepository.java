package com.hospitalcrud.dao.repository.jdbc;

import com.hospitalcrud.dao.model.Credential;
import com.hospitalcrud.dao.model.Patient;
import com.hospitalcrud.dao.repository.CredentialDAO;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Profile("jdbc")
@Log4j2
public class CredentialRepository implements CredentialDAO {

    private final JdbcTemplate jdbcTemplate;
    //private final RowMapper<Patient> patientRowMapper = new BeanPropertyRowMapper<>(Patient.class);
    private final RowMapper<Credential> credentialRowMapper = new BeanPropertyRowMapper<>(Credential.class);
    public CredentialRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    //TODO JDBC CREDENCIALES
    @Override
    public List<Credential> getAll() {
        return List.of();
    }

    @Override
    public int save(Credential c) {
        return 0;
    }

    @Override
    public void update(Credential c) {/*bla bla bla*/}

    @Override
    public boolean delete(int id, boolean confirmation) {
        return false;
    }

    public boolean validateUsername(String username) {
        return false;
    }

    public boolean login(String username,String  password) {
        return false;
    }
}
