package com.hospitalcrud.service;

import com.hospitalcrud.dao.repository.CredentialDAO;
import com.hospitalcrud.dao.repository.jdbc.CredentialRepository;
import org.springframework.stereotype.Service;

@Service
public class CredentialService {
    private final CredentialRepository dao;
    public CredentialService(CredentialRepository dao) {
        this.dao = dao;
    }

    public boolean isValidUsername(String username) {
        return dao.validateUsername(username);
    }

    public boolean isPasswordCorrect(String username, String password) {
        return dao.login(username, password);
    }
    // TODO IMPLEMENTAR CREDENCIALES, METODOS DE AUTENTICACION
}
