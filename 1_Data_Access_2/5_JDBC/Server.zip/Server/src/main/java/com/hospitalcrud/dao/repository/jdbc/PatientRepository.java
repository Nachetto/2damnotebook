package com.hospitalcrud.dao.repository.jdbc;

import com.hospitalcrud.common.Constants;
import com.hospitalcrud.dao.model.Patient;
import com.hospitalcrud.dao.repository.PatientDAO;
import com.hospitalcrud.domain.error.InternalServerErrorException;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
@Profile("jdbc")
@Log4j2
public class PatientRepository implements PatientDAO {
    private final JdbcTemplate jdbcTemplate;
    private final RowMapper<Patient> patientRowMapper = new BeanPropertyRowMapper<>(Patient.class);

    public PatientRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Patient> getAll() {
        try {
            String sql = Constants.GET_ALL_PATIENTS;
            return jdbcTemplate.query(sql, patientRowMapper);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
            throw new InternalServerErrorException("Error fetching patients: " + e.getMessage());
        }
    }

    @Override
    public int save(Patient patient) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("name", patient.getName());
        parameters.addValue("birthdate", Date.valueOf(patient.getBirthDate()));
        parameters.addValue("phone", patient.getPhone());

        int update = namedParameterJdbcTemplate.update(Constants.INSERT_PATIENT, parameters, keyHolder, new String[]{"id"});

        if (update > 0 && keyHolder.getKey() != null) {
            return keyHolder.getKey().intValue();
        }
        return -1;
    }

    @Override
    public void update(Patient patient) {
        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("name", patient.getName());
        parameters.addValue("birthdate", Date.valueOf(patient.getBirthDate()));
        parameters.addValue("phone", patient.getPhone());
        parameters.addValue("id", patient.getId());

        namedParameterJdbcTemplate.update(Constants.UPDATE_PATIENT, parameters);
    }

    @Override
    public boolean delete(int id, boolean confirmation) {
        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
        MapSqlParameterSource parameters = new MapSqlParameterSource().addValue("id", id);

        return namedParameterJdbcTemplate.update(Constants.DELETE_PATIENT, parameters) > 0;
    }
}

