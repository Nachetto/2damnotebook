package com.hospitalcrud.dao.repository.jdbc;

import com.hospitalcrud.dao.model.Doctor;
import com.hospitalcrud.dao.model.Patient;
import com.hospitalcrud.dao.repository.DoctorDAO;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Profile("jdbc")
@Log4j2
public class DoctorRepository  implements DoctorDAO {

    private final JdbcTemplate jdbcTemplate;
    //private final RowMapper<Patient> patientRowMapper = new BeanPropertyRowMapper<>(Patient.class);
    private final RowMapper<Doctor> doctorRowMapper = new BeanPropertyRowMapper<>(Doctor.class);
    public DoctorRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Doctor> getAll() {
        return List.of();
    }

    @Override
    public int save(Doctor m) {
        return 0;
    }


    @Override
    public void update(Doctor doctor) {

    }

    @Override
    public boolean delete(int id, boolean confirmation) {
        return false;
    }
}
