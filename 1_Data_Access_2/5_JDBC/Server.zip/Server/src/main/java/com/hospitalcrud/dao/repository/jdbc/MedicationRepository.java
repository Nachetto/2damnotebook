package com.hospitalcrud.dao.repository.jdbc;

import com.hospitalcrud.dao.model.Medication;
import com.hospitalcrud.dao.repository.MedicationDAO;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Profile("jdbc")
@Log4j2
public class MedicationRepository implements MedicationDAO {

    private final JdbcTemplate jdbcTemplate;
    private final RowMapper<Medication> medicationRowMapper = new BeanPropertyRowMapper<>(Medication.class);

    public MedicationRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Medication> getAll() {
        return List.of();
    }

    @Override
    public int save(Medication m) {
        return 0;
    }

    @Override
    public void update(Medication m) {

    }

    @Override
    public boolean delete(int id, boolean confirmation) {
        return false;
    }

    public List<Medication> get(int medRecordId) {
        return List.of();
    }
}
