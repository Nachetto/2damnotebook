package com.hospitalcrud.ui;

import com.hospitalcrud.dao.model.Credential;
import com.hospitalcrud.service.CredentialService;
import com.hospitalcrud.service.PatientService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://127.0.0.1:5500")
@RequestMapping("/login")
public class RestCredential {

    private final CredentialService credentialService;
    public RestCredential(CredentialService credentialService) {
        this.credentialService = credentialService;
    }

    /*
    if username and password match, return 200
    if username and password do not match, return 401
    if username does not exist, return 404
    if password is incorrect, return 401
    if username is empty, return 400
    if password is empty, return 400
    if username is null, return 400
    if password is null, return 400
    if username is not a string, return 400
    if password is not a string, return 400
    */
    @PostMapping
    public ResponseEntity<String> login(@RequestBody Credential credential) { //TODO this validations should go in the service
        if (credential.getUsername() == null || credential.getPassword() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username or password is null");
        }
        if (credential.getUsername().isEmpty() || credential.getPassword().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username or password is empty");
        }
        if (!credentialService.isValidUsername(credential.getUsername())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Username does not exist");
        }
        if (credentialService.isPasswordCorrect(credential.getUsername(), credential.getPassword())) {
            return ResponseEntity.ok("true");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
    }

}
