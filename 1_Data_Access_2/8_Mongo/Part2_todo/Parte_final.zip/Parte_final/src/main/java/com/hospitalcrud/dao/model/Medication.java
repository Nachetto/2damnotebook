package com.hospitalcrud.dao.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data

public class Medication {
    private String name;
}




