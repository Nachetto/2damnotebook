package com.hospitalcrud.dao.repositories;

import com.hospitalcrud.dao.model.Payment;

import java.util.List;

public interface PaymentsRepository {
    List<Payment> getAll();
    void delete(int id);
}
