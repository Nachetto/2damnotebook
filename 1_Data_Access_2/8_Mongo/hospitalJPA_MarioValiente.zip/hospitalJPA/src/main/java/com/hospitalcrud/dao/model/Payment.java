package com.hospitalcrud.dao.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "patient_payments")
@NamedQuery(name = "HQL_GET_ALL_PAYMENTS",
        query = "from Payment ")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private int paymentId;
    @Column(name = "patient_id")
    private int patientId;
    @Column
    private double amount;
    @Column(name = "payment_date")
    private LocalDate paymentDate;
}
