package com.hospitalcrud.dao.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class Medication {
    private int id;
    private String medicationName;
    private int medRecordId;
    private String dosage;

    public Medication(int prescriptionId, int recordId, String medicationName, String dosage) {
        this.id = prescriptionId;
        this.medRecordId = recordId;
        this.medicationName = medicationName;
        this.dosage = dosage;
    }

    public Medication(int i, String m, int id) {
        this.id = i;
        this.medRecordId = id;
        this.medicationName = m;
    }
}
