package com.hospitalcrud.dao.repositories;

import com.hospitalcrud.dao.model.Patient;

import java.util.List;

public interface PatientRepository {
    List<Patient> getAll();

    int save(Patient patient);

    void update(Patient patient);

    void delete(int id, boolean confirmation);
}
