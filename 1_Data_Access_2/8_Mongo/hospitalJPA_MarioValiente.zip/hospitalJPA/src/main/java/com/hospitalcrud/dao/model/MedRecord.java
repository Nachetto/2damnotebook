package com.hospitalcrud.dao.model;

import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MedRecord {

    private int id;
    private int idPatient;

    private int idDoctor;
    private String diagnosis;
    private LocalDate date;

    private List<Medication> medications;

    public MedRecord(int recordId, int patientId, int doctorId, String diagnosis, LocalDate admissionDate) {
        this.id = recordId;
        this.idPatient = patientId;
        this.idDoctor = doctorId;
        this.diagnosis = diagnosis;
        this.date = admissionDate;
    }
}
