package com.hospitalcrud.dao.repositories.jpa;

import com.hospitalcrud.dao.model.MedRecord;
import com.hospitalcrud.dao.repositories.MedRecordRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.util.List;
@Log4j2
@Repository
public class MedRecordJPARepository implements MedRecordRepository {
    @Override
    public List<MedRecord> getAll() {
        return List.of();
    }

    @Override
    public int save(MedRecord medRecord) {
        return 0;
    }

    @Override
    public void delete(MedRecord medRecord) {

    }

    @Override
    public void update(MedRecord medRecord) {

    }
}
