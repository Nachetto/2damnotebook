package com.hospitalcrud.dao.repositories;


import com.hospitalcrud.dao.model.Credential;

public interface CredentialRepository {
    void save(Credential credential);
    Credential get(String username);
    void delete(int id);
}
