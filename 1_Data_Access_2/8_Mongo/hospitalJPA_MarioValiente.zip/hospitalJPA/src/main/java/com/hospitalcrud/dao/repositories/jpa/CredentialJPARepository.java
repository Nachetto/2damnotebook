package com.hospitalcrud.dao.repositories.jpa;

import com.hospitalcrud.dao.model.Credential;
import com.hospitalcrud.dao.repositories.CredentialRepository;
import com.hospitalcrud.dao.repositories.jpa.utils.JPAUtil;
import jakarta.persistence.EntityManager;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

@Log4j2
@Repository
public class CredentialJPARepository implements CredentialRepository {
    private final JPAUtil jpaUtil;
    private EntityManager em;

    public CredentialJPARepository(JPAUtil jpaUtil) {
        this.jpaUtil = jpaUtil;
    }

    @Override
    public void save(Credential credential) {

    }

    @Override
    public Credential get(String username) {
        Credential credential = null;
        em = jpaUtil.getEntityManager();
        try {
            credential = em.createNamedQuery("HQL_GET_CREDENTIAL", Credential.class)
                    .setParameter(1, username)
                    .getSingleResult();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
        return credential;
    }

    @Override
    public void delete(int id) {

    }
}
