package com.hospitalcrud.domain.services;

import com.hospitalcrud.dao.model.Credential;
import com.hospitalcrud.dao.repositories.CredentialRepository;
import com.hospitalcrud.domain.model.CredentialUI;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class CredentialService {

    private final CredentialRepository credentialRepository;

    public CredentialService(CredentialRepository credentialRepository) {
        this.credentialRepository = credentialRepository;
    }

    public boolean get(CredentialUI credentialui) {
        Credential credentialR = this.credentialRepository.get(credentialui.getUsername());
        if (credentialR == null) {
            return false;
        }
        return Objects.equals(credentialR.getPassword(), credentialui.getPassword());
    }
}
