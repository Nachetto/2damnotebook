package com.hospitalcrud.dao.repositories.jpa;

import com.hospitalcrud.dao.model.Patient;
import com.hospitalcrud.dao.repositories.PatientRepository;
import com.hospitalcrud.dao.repositories.jpa.utils.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.PersistenceException;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Log4j2
@Repository
public class PatientJPARepository implements PatientRepository {
    private final JPAUtil jpaUtil;
    private EntityManager em;

    public PatientJPARepository(JPAUtil jpaUtil) {
        this.jpaUtil = jpaUtil;
    }

    @Override
    public List<Patient> getAll() {
        List<Patient> patients = new ArrayList<>();
        em = jpaUtil.getEntityManager();
        try {
            patients = em.createNamedQuery("HQL_GET_ALL_PATIENTS", Patient.class).getResultList();
        } catch (PersistenceException e) {
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
        return patients;
    }

    @Override
    public int save(Patient patient) {
        em = jpaUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(patient);
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
        return patient.getId();
    }

    @Override
    public void update(Patient patient) {
        em = jpaUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        try {
            em.merge(patient);
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
    }

    @Override
    public void delete(int id, boolean confirmation) {
        em = jpaUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        try {
            Patient patient = new Patient(id);
            em.remove(em.merge(patient));
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
    }
}
