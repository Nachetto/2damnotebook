package com.hospitalcrud.domain.services;

import com.hospitalcrud.dao.model.Credential;
import com.hospitalcrud.dao.model.Patient;
import com.hospitalcrud.dao.model.Payment;
import com.hospitalcrud.dao.repositories.PatientRepository;
import com.hospitalcrud.dao.repositories.PaymentsRepository;
import com.hospitalcrud.domain.model.PatientUI;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PatientService {
    private final PatientRepository patientRepository;
    private final PaymentsRepository paymentsRepository;

    public PatientService(PatientRepository patientRepository, PaymentsRepository paymentsRepository) {
        this.patientRepository = patientRepository;
        this.paymentsRepository = paymentsRepository;
    }

    public List<PatientUI> getAll() {
        List<Patient> patients = patientRepository.getAll();
        List<Payment> paymentList = paymentsRepository.getAll();
        List<PatientUI> patientsUI = new ArrayList<>();
        patients.forEach(patient -> {
            double paidAmount = paymentList.stream()
                    .filter(payment -> payment.getPatientId() == patient.getId())
                    .mapToDouble(Payment::getAmount)
                    .findFirst()
                    .orElse(0.0);
            patientsUI.add(new PatientUI(patient.getId(), patient.getName(), null,
                    patient.getBirthDate(), patient.getPhone(), paidAmount, null));
        });
        return patientsUI;
    }

    public int save(PatientUI patientUI) {
        Credential credential = new Credential(0,patientUI.getUserName(), patientUI.getPassword(), 0, 0);
        Patient patient = new Patient(patientUI.getId(), patientUI.getName(), patientUI.getBirthDate(), patientUI.getPhone(), credential);
        return patientRepository.save(patient);
    }

    public void update(PatientUI patientUI) {
        Patient patient = new Patient(patientUI.getId(), patientUI.getName(), patientUI.getBirthDate(), patientUI.getPhone());
        patientRepository.update(patient);
    }

    public void delete(int patientId, boolean confirm) {
        patientRepository.delete(patientId, confirm);
    }
}
