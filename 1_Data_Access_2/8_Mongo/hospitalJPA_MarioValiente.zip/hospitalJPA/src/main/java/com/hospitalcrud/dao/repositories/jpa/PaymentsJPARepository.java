package com.hospitalcrud.dao.repositories.jpa;

import com.hospitalcrud.dao.model.Payment;
import com.hospitalcrud.dao.repositories.PaymentsRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.util.List;

@Log4j2
@Repository
public class PaymentsJPARepository implements PaymentsRepository {

    @Override
    public List<Payment> getAll() {
       return List.of();
    }

    @Override
    public void delete(int id) {

    }
}
