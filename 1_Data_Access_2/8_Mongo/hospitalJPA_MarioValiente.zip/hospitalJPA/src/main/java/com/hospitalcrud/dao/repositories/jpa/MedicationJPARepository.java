package com.hospitalcrud.dao.repositories.jpa;

import com.hospitalcrud.dao.model.Medication;
import com.hospitalcrud.dao.repositories.MedicationRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.util.List;
@Log4j2
@Repository
public class MedicationJPARepository implements MedicationRepository {
    @Override
    public List<Medication> getAll() {
        return List.of();
    }

    @Override
    public void update(List<Medication> medications) {

    }

    @Override
    public void delete(Medication medication) {

    }
}
