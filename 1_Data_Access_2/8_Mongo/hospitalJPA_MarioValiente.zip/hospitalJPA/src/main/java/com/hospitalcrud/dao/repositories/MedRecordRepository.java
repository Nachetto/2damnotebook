package com.hospitalcrud.dao.repositories;

import com.hospitalcrud.dao.model.MedRecord;

import java.util.List;

public interface MedRecordRepository {
    List<MedRecord> getAll();
    int save(MedRecord medRecord);
    void delete(MedRecord medRecord);
    void update(MedRecord medRecord);
}
