package com.hospitalcrud.domain.services;

import com.hospitalcrud.dao.model.MedRecord;
import com.hospitalcrud.dao.model.Medication;
import com.hospitalcrud.dao.repositories.MedRecordRepository;
import com.hospitalcrud.dao.repositories.MedicationRepository;
import com.hospitalcrud.domain.model.MedRecordUI;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class MedRecordService {
    private final MedRecordRepository medRecordRepository;
    private final MedicationRepository medicationRepository;

    public MedRecordService(MedRecordRepository medRecordRepository, MedicationRepository medicationRepository) {
        this.medRecordRepository = medRecordRepository;
        this.medicationRepository = medicationRepository;
    }

    public List<MedRecordUI> getAll(int idPatient) {
        List<MedRecord> medRecords = medRecordRepository.getAll();
        List<MedRecordUI> medRecordUI = new ArrayList<>();
        medRecords.forEach(m -> medRecordUI.add(new MedRecordUI(m.getId(), m.getDiagnosis(), m.getDate().toString(),
                m.getIdPatient(), m.getIdDoctor(), getMed(m, medicationRepository.getAll()))));
        return medRecordUI.stream()
                .filter(medRecordUI1 -> medRecordUI1.getIdPatient() == idPatient)
                .toList();
    }


    public List<String> getMed(MedRecord m, List<Medication> medications) {
        List<String> medicationsName = new ArrayList<>();
        medications.stream().filter(medication -> m.getId() == medication.getMedRecordId())
                .forEach(medication -> medicationsName.add(medication.getMedicationName()));
        return medicationsName;
    }

    public int save(MedRecordUI medRecordui) {
        MedRecord medRecord = new MedRecord(medRecordui.getId(), medRecordui.getIdPatient(), medRecordui.getIdDoctor(),
                medRecordui.getDescription(), LocalDate.parse(medRecordui.getDate()), getMed(medRecordui));

        return medRecordRepository.save(medRecord);
    }

    public void delete(int id) {
        MedRecord medRecord = new MedRecord(id, 0, 0, null, null);
        medRecordRepository.delete(medRecord);
    }

    public void update(MedRecordUI medRecordUI) {
        MedRecord medRecord = new MedRecord(medRecordUI.getId(), medRecordUI.getIdPatient(), medRecordUI.getIdDoctor(),
                medRecordUI.getDescription(), LocalDate.parse(medRecordUI.getDate()), getMed(medRecordUI));
        medicationRepository.update(medRecord.getMedications());
        medRecordRepository.update(medRecord);
    }

    private List<Medication> getMed(MedRecordUI medRecordui) {
        List<Medication> medications = new ArrayList<>();
        medRecordui.getMedications().forEach(m -> medications.add(new Medication(10, m, medRecordui.getId(), "10ml")));
        return medications;
    }
}
