package com.hospitalcrud.dao.repositories.jpa;

import com.hospitalcrud.dao.model.Doctor;
import com.hospitalcrud.dao.repositories.DoctorRepository;
import com.hospitalcrud.dao.repositories.jpa.utils.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceException;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Log4j2
@Repository
public class DoctorJPARepository implements DoctorRepository {
    private final JPAUtil jpaUtil;
    private EntityManager em;

    public DoctorJPARepository(JPAUtil jpaUtil) {
        this.jpaUtil = jpaUtil;
    }

    @Override
    public List<Doctor> getAll() {
        List<Doctor> doctors = new ArrayList<>();
        em = jpaUtil.getEntityManager();
        try {
            doctors = em.createNamedQuery("HQL_GET_ALL_DOCTORS", Doctor.class).getResultList();
        } catch (PersistenceException e) {
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
        return doctors;
    }
}
