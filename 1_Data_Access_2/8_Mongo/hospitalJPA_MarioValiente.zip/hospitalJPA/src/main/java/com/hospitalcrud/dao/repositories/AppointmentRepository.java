package com.hospitalcrud.dao.repositories;

public interface AppointmentRepository {
    void delete(int id);
}
