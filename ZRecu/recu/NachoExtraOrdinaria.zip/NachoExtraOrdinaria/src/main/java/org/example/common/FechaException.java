package org.example.common;

public class FechaException extends Exception {
    public FechaException(String mensaje){
        super(mensaje);
    }
}
