package org.example.ui;

public class Main {
    public static void main(String[] args) {
        VueloMain vueloMain = new VueloMain();
        vueloMain.run();
    }
}
