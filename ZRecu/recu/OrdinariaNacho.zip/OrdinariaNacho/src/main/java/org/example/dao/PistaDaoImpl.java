package org.example.dao;

import org.example.common.ComparacionPorProvincia;
import org.example.common.Constantes;
import org.example.common.DificultadExcepcion;
import org.example.common.VerificarDificultadExcepcion;
import org.example.domain.Pista;
import org.example.domain.SkiFondo;
import org.example.domain.SkipAlpino;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class PistaDaoImpl implements PistaDao {
    List<Pista> pistas = null;

    public PistaDaoImpl() {
        pistas = new ArrayList<>();
    }

    public void agregarValoresIniciales(){
        try {
            pistas.add(new SkipAlpino(1, (int) Math.floor(Math.random() * 5) + 1, "Madrid", "Aliga", "Roja"));//al ser ski de Alpino hay menos kilómetros que en el Ski Fondo
            pistas.add(new SkipAlpino(2, (int) Math.floor(Math.random() * 5) + 1, "Barcelona", "Pinflon", "verde"));
            pistas.add(new SkipAlpino(3, (int) Math.floor(Math.random() * 5) + 1, "Alicante", "Casteo", "Azul"));
            pistas.add(new SkipAlpino(4, (int) Math.floor(Math.random() * 5) + 1, "Valencia", "Fallaski", "verde"));
        } catch (DificultadExcepcion e) {
            System.out.println("Es literalmente imposible que esta excepción salte porque he sido yo el que introduce los datos y no el usuario pero" +
                    " mejor hago el try catch aqui que no cuando vaya a construir pistadaoimpl");
        }
        pistas.add(new SkiFondo(5, (int) Math.floor(Math.random() * 10) + 1, "Sevilla", "Colorespecial", "lagunas", "algete"));//al ser ski de Fondo hay mas kilómetros que en el Ski Alpino
        pistas.add(new SkiFondo(6, (int) Math.floor(Math.random() * 10) + 1, "PaisVasco", "Euskera", "mungia", "gatica"));
        pistas.add(new SkiFondo(7, (int) Math.floor(Math.random() * 10) + 1, "Asturias", "Gaitas", "sidra", "llanes"));
        pistas.add(new SkiFondo(8, (int) Math.floor(Math.random() * 10) + 1, "Galicia", "cocacola", "oporto", "fedora"));
    }

    @Override
    public List<Pista> getListaPistas() {
        return pistas;
    }

    @Override
    public List<Pista> listadoOrdenadoProvinciaKm(String provincia) {
        return pistas.stream()
                .filter(pista -> getPistasProvincia().equals(provincia))
                .sorted(new ComparacionPorProvincia())
                .collect(Collectors.toList());
    }

    @Override
    public boolean addPista(SkipAlpino pista) throws DificultadExcepcion {
        boolean resultado = false;
        VerificarDificultadExcepcion.verificandoDificultadExcepcion(pista.getDificultad());
        pistas.add(pista);
        resultado = true;
        return resultado;
    }

    @Override
    public boolean addPista(SkiFondo pista) {
        pistas.add(pista);
        return true;
    }

    public void nuevaPistaFondo(String provincia, String nombre, String pueblo1, String pueblo2, int id) {
        Pista nueva = new SkiFondo(id, (int) Math.floor(Math.random() * 10) + 1, provincia, nombre, pueblo1, pueblo2);
        if (addPista((SkiFondo) nueva))
            System.out.println(Constantes.SKIFONDOOK);
        else
            System.out.println(Constantes.SKIFONDOMAL);
    }

    public void nuevaPistaAlpina(int id, String provincia, String nombre,String dificultad) throws DificultadExcepcion {
        Pista nueva = new SkipAlpino(id,(int) Math.floor(Math.random() * 5) + 1,provincia,nombre,dificultad);
        if (addPista((SkipAlpino) nueva))
            System.out.println(Constantes.SKIFONDOOK);
        else
            System.out.println(Constantes.SKIFONDOMAL);
    }


    @Override
    public int consulta(String provincia) {
        double result = pistas.stream()
                .filter(pista -> getPistasProvincia().contains(provincia))
                .mapToDouble(Pista::getKm).sum();
        return (int) result;
    }

    @Override
    public boolean addPuebloListaPueblos(int id, String pueblo) {
        boolean respuesta = false;
        SkiFondo s = (SkiFondo) pistas.get(id);
        List<String> cambiada = s.getPueblos();
        cambiada.add(pueblo);
        s.setPueblos(cambiada);
        pistas.remove(id);
        pistas.add(s);
        respuesta = true;
        return respuesta;
    }

    @Override
    public boolean removePista(int id) {
        boolean respuesta = false;
        try {
            pistas.remove(id);
            respuesta = true;
        } catch (NullPointerException e) {
            System.out.println("No exise una pista con ese identificador");
        }
        return respuesta;
    }

    @Override
    public String getPistasProvincia() {
        return "Madrid";
    }

//    @Override
//    public String getPistasProvincia(Pista p) {
//        String[] resultado = new String[6];
//        //resultado = this.pistas.stream().map(Pista::getProvincia).collect(Collectors.toList()).toString().split(";");
//        return "Madrid";
//    }

    @Override
    public List<Pista> cargarFichero() {
        Scanner scanner = null;
        pistas = new ArrayList<>();
        try {
            scanner = new Scanner(new File("FicheroTXT"));
            while (scanner.hasNextLine()) {
                String[] resultado = new String[6];
                resultado = scanner.nextLine().split(";");
                Pista pista = null;
                if (resultado[0].equalsIgnoreCase("skialpino")) {
                    //pista = new SkipAlpino(resultado));
                } else
                    //pista = new SkiFondo(resultado);
                    pistas.add(pista);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        } /*catch (DificultadExcepcion e) {
            System.out.println("Hey, no puedes crear una pista porque la dificultad no existe");
        }*/
        return pistas;
    }

    @Override
    public boolean escribirFichero() {
        boolean respuesta = false;
        try (PrintWriter writer = new PrintWriter(new
                FileWriter("FicheroTXT"))) {
            writer.println(this.toString());
            System.out.println("El usuario se ha guardado correctamente en  el archivo.");
            respuesta = true;
        } catch (IOException e) {
            System.err.println("Error al guardar el usuario en el archivo: "
                    + e.getMessage());
        }
        return respuesta;
    }

    @Override
    public boolean escribirFicheroBinario() {
        try {
            FileOutputStream archivoBinario = new FileOutputStream("FicheroBIN");
            ObjectOutputStream escribir = new ObjectOutputStream(archivoBinario);
            escribir.writeObject(pistas);
            archivoBinario.close();
            escribir.close();
            System.out.println("Todo guardado.");
            return true;
        } catch (IOException e) {
            System.out.println("Ha habido un error al guardar el archivo binario.");
            return false;
        }
    }

    @Override
    public List<Pista> cargarFicheroBinario() {
        List<Pista> resultado = new ArrayList<>();
        try {
            FileInputStream archivoBinario = new FileInputStream("FicheroBIN");
            ObjectInput leer = null;
            leer.readObject();
            archivoBinario.close();
            leer.close();
            System.out.println("Todo leído.");
            return resultado;
        } catch (IOException e) {
            System.out.println("Ha habido un error al guardar el archivo binario.");
            return resultado;
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}