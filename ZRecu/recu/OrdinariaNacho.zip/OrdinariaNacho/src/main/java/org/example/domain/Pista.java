package org.example.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Pista {
    protected int id, km;
    protected String provincia, nombre;

}