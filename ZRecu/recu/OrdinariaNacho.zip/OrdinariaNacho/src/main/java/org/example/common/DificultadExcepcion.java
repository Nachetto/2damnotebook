package org.example.common;

public class DificultadExcepcion extends Exception{
    public DificultadExcepcion(String mensaje){
        super(mensaje);
    }
}
