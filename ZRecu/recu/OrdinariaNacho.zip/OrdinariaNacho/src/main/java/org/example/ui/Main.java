package org.example.ui;

public class Main {
    public static void main(String[] args) {
        PistaMain p = new PistaMain();
        p.run();
    }
}
