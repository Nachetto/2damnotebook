package domain.modelo.errores;



public class OtraException extends RuntimeException{


    public OtraException(String error) {
        super(error);
    }
}
