package dao;

public enum Errores {
    ERROR,DUPLICLATE_KEY
}
