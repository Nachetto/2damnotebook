//module javafx11.multipantallaTest {
//
//    requires javafx.graphics;
//    requires javafx.controls;
//    requires javafx.fxml;
//    requires MaterialFX;
//
//    requires lombok;
//    requires org.apache.logging.log4j;
//
//    requires jakarta.inject;
//    requires jakarta.cdi;
//    requires org.junit.jupiter.api;
//    requires org.testfx;
//    requires org.testfx.junit5;
//    requires javafx11.multipantalla;
//
//
//    exports ui to org.junit.platform.commons;
//    opens ui to  org.testfx.junit5;
//
//
//}
