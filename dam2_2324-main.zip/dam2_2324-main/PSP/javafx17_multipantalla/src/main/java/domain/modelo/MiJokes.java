package domain.modelo;

public record MiJokes(int id, String joke) {


}

