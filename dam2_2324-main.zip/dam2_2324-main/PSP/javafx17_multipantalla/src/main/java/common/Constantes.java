package common;

public class Constantes {


    public static final String NOMBRE = "Nombre desde una cte";
}
