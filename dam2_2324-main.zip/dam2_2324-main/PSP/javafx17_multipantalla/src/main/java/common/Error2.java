package common;

public final class Error2 extends ErrorApp {
    public Error2(String mensaje) {
        super(mensaje);
    }



}
