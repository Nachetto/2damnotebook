package common;

public final class Error4 extends ErrorApp {

    public Error4(String mensaje) {
        super(mensaje);
    }
}
