package common;

public final class Loading<T> extends ResultMio<T> {
    public Loading() {
        super(null, null);
    }
}
