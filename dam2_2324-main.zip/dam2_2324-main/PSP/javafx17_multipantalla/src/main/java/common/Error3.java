package common;

public final class Error3 extends ErrorApp {

    public Error3(String mensaje) {
        super(mensaje);
    }
}
