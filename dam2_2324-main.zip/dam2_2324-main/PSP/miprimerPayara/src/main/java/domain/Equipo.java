package domain;


import lombok.Data;

@Data
public class Equipo {

    private final String id;
    private final String nombre;
    private final String ciudad;
    private final String estadio;

}
