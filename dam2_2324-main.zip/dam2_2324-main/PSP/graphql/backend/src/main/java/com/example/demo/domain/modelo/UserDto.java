package com.example.demo.domain.modelo;

public record UserDto( Long id, String nombre) {
}
