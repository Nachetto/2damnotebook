package com.example.demo.domain.modelo;

public record Rol(Long id, String rol) {
}
