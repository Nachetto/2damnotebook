package com.example.demo.domain.modelo.graphql;

public record CiudadInput(
        Long id, String nombre


) {
}
