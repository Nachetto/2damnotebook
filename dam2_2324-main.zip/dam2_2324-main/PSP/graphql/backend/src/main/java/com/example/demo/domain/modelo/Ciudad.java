package com.example.demo.domain.modelo;

public record Ciudad(Long id, String nombre) {
}
