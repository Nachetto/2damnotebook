package com.example.demo.ui.auth;

import lombok.Data;


public record AuthRequest(String username, String password) {

}
