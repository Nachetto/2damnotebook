rootProject.name = "frontend"
