package com.example.flows.framework.main

import com.example.flows.domain.modelo.Movie

data class MainState( val movies: List<Movie>)