package com.example.flows.data.modelo

class TrendingMovieResponse(
    val results: List<MovieEntity>?
)