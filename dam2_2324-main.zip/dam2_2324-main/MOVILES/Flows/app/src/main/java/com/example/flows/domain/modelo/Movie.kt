package com.example.flows.domain.modelo

data class Movie (val titulo:String)