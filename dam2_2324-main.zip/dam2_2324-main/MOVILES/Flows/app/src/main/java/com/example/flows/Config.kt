package com.example.flows

object Config {
    const val BASE_URL = "https://api.themoviedb.org"
    const val IMAGE_URL = "https://image.tmdb.org/t/p/original";
}