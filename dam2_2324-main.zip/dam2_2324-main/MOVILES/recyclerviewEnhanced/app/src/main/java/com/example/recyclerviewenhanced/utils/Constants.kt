package com.example.recyclerviewenhanced.utils

object Constants {



        const val BASE_URL = "https://dog.ceo/"
        const val RANDOM_URL = "api/breeds/image/random"



}