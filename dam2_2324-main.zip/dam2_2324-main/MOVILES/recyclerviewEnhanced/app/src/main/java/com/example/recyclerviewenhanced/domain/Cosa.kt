package com.example.recyclerviewenhanced.domain

data class Cosa(
    val nombre: String,
    val id: Int,
)
