package com.example.recyclerviewenhanced.domain



data class Dog(val nombre:String )


