package com.example.navigationdecero.ui.pantallas

data class FragmentState(val cadenas: List<String> = emptyList(),
                         val error: String? = null,)


