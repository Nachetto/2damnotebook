package com.example.navigationdecero.ui.pantallas

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FragmentApp : Application() {
    override fun onCreate() {
        super.onCreate()


    }

}