package com.example.roomviewmodel.ui

import android.app.Application

class RoomApp : Application() {


}