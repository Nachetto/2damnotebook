package com.example.roomviewmodel.domain.modelo


data class Cosa(
    val nombre: String,
    val id: Int,
)
