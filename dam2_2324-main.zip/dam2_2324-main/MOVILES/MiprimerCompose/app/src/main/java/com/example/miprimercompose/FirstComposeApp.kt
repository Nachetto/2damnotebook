package com.example.miprimercompose

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class FirstComposeApp : Application()