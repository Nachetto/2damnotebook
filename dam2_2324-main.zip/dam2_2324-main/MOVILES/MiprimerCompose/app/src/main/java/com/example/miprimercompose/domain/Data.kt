package com.example.fistcompose.domain

data class Data(val id:Int,val nombre:String)