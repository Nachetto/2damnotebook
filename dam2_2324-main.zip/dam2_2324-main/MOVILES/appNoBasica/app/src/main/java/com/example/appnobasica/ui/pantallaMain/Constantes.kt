package com.example.appnobasica.ui.pantallaMain

object Constantes {


    const val ERROR = "error"

}