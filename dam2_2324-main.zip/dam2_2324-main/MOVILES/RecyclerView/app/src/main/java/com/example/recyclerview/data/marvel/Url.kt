package com.example.recyclerview.data.marvel

data class Url(
    val type: String,
    val url: String
)