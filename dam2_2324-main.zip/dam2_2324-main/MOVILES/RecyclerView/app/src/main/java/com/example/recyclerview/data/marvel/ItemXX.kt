package com.example.recyclerview.data.marvel

data class ItemXX(
    val name: String,
    val resourceURI: String
)