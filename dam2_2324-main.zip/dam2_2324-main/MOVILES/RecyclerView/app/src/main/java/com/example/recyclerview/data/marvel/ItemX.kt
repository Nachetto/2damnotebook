package com.example.recyclerview.data.marvel

data class ItemX(
    val name: String,
    val resourceURI: String
)