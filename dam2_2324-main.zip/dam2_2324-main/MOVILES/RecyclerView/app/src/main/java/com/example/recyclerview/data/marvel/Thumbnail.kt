package com.example.recyclerview.data.marvel

data class Thumbnail(
    val extension: String,
    val path: String
)