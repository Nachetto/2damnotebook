package com.example.recyclerview.data.marvel

data class ItemXXX(
    val name: String,
    val resourceURI: String,
    val type: String
)