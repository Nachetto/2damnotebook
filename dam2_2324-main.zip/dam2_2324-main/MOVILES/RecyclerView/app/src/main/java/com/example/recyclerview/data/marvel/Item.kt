package com.example.recyclerview.data.marvel

data class Item(
    val name: String,
    val resourceURI: String
)