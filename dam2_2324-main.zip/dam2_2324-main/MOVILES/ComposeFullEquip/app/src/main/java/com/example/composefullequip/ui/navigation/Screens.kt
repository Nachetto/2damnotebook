package com.example.composefullequip.ui.navigation





val screensBottomBar = listOf(
    Screens("listado"),

    Screens("pantalla"),
)

data class Screens(val route: String) {

}
