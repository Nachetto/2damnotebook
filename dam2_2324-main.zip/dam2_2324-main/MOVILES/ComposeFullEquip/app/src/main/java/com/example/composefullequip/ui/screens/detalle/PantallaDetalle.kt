package com.example.composefullequip.ui.screens.detalle

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PantallaDetalle(
    personaId: String
) {


    Text("Pantalla Detalle ${personaId}" )
    
}