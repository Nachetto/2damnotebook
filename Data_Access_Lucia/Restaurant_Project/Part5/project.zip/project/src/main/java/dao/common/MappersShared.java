package dao.common;

public class MappersShared {
}
