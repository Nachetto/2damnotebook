package com.example.myapplication.ui.pantallaRaton

object Constantes {
    const val RATON_NO_ENCONTRADO = "Raton no encontrado"
    const val RATON_MODIFICADO = "Raton modificado"
    const val RATON_ELIMINADO = "Raton eliminado"
    const val RATON_ANADIDO = "Raton añadido"
    const val ERROR = "error"
}