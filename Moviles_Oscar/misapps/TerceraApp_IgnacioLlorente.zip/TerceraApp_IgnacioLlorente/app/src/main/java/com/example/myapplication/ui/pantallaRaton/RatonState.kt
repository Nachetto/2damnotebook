package com.example.myapplication.ui.pantallaRaton

data class RatonState(
    val mensaje: String? = null
)

