package ui.pantallas.login;

import lombok.Data;

@Data
public class LoginState {

    private final boolean loginOK;
    private final String error;

}
