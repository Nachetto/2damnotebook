package ui.pantallas.detalle;

public class DetalleState {
}
