package domain.modelo;

import lombok.Data;


public record Usuario(String nombre, String password){
}
