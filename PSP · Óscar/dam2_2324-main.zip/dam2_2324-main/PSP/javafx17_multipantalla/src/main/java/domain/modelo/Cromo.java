package domain.modelo;

import lombok.Data;

@Data
public class Cromo {

    private final String collecion;
    private final int numero;
    private final String descripcion;
}
