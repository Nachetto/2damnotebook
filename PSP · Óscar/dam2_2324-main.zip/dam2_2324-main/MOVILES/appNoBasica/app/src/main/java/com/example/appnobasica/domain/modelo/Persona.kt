package com.example.appnobasica.domain.modelo


data class Persona(val nombre:String)


