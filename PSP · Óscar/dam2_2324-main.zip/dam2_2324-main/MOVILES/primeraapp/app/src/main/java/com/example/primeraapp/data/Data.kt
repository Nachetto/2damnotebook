package com.example.primeraapp.data

class Data( var user: String) {

    init {


    }


}