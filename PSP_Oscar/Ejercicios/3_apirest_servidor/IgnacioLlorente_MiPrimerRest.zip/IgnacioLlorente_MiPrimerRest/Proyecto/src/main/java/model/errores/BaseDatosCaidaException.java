package model.errores;

public class BaseDatosCaidaException extends RuntimeException{


    public BaseDatosCaidaException(String message) {
        super(message);
    }
}
