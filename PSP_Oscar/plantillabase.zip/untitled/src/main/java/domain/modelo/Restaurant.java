package domain.modelo;

import dao.model.Customer;

import java.util.List;

public interface Restaurant {
    List<Customer> customers = null;

}
