package common;

public class Constantes {


    public static final String NOMBRE = "Nombre desde una cte";
    public static final String BIENVENIDA = "HOLA DE NUEVO, ";
}
