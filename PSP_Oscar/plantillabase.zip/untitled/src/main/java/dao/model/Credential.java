package dao.model;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Credential {
    private final String username, password;

}
