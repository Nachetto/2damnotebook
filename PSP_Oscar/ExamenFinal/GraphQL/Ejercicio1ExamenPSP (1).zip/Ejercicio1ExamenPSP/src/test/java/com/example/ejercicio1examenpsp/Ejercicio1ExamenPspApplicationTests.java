package com.example.ejercicio1examenpsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio1ExamenPspApplicationTests {

	@Test
	void contextLoads() {
	}

}
