package common;

public class Constantes {
    public static final String ERROR_CONEXION = "Error de comunuicación con el servidor";
    public static final String CONFIG_PROPERTIES = "config/config.properties";
}
