package dao.retrofit.modelo;

import lombok.Data;

import java.util.List;
@Data
public class ResponseEpisode {
    private List<ResultsItemEpisode> results;
}
