package ui.pantallas.principal;

import lombok.Data;

@Data
public class ParametrosBusquedaCharacter {
    private int limite;
}
